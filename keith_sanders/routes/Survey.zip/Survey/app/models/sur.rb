class Sur < ActiveRecord::Base
end
