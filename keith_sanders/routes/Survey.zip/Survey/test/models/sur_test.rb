require 'test_helper'

class SurTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
