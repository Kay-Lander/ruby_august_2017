class DojosController < ApplicationController
    def index
        @Dojo = Dojo.all 
    end
end
