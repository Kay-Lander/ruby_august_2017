module RpgsHelper
end
