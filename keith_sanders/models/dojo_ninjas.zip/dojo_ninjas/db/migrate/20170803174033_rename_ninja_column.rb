class RenameNinjaColumn < ActiveRecord::Migration
  def change
  end
end
