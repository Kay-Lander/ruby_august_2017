class Post < ActiveRecord::Base
  belongs_to :Blog
  validates :title, presence: true, length: { minimum:7 }
  validates :content, presence: true
end
